create database tweetAppComp1;
use tweetAppComp1;
show tables;

create table USERDETAILS (
userid varchar(20) primary key not null,
emailid varchar(20),
name varchar(20),
password varchar(20),
phoneno varchar(10),
picture varchar(20)
);

create table ADMIN(
userid varchar(20) primary key not null,
password varchar(20)
);

drop table admin;
create table TWEETDETAILS(
tweetid varchar(20) primary key not null,
tweettext varchar(20) ,
tweetdate datetime
);

insert into Admin values ("AD1","123456");
insert into Admin values ("AD2","456789");
select * from Admin;

select * from tweetdetails;
insert into TWEETDETAILS values("TWT1","Hey There","2022-03-12");
insert into TWEETDETAILS values("TWT2","Its a tweet","2022-02-12");
insert into TWEETDETAILS values("TWT3","Hey ThereIts atweet","2022-01-12");

insert into USERDETAILS values("U1","abc@gmail.com","Debarati","123456","9339779392","jpg1");
insert into USERDETAILS values("U2","xyz@gmail.com","Roshni","456789","9339779391","jpg2");
select * from userdetails;
