package com.tweetapp.service;

import com.tweetapp.model.Tweet;
import com.tweetapp.model.User;

import java.util.List;

public interface TweetService {

    List<Tweet> viewAllTweets();
    Tweet findTweetById(String tweetId);
    Tweet addTweets(Tweet tweet);

    List<User> viewAllUsers();
    User findUserByEmailId(String emailId);
    User addUsers(User user);

    void login(String emailId, String password);
    void forgetPassword(String emailId, String password);
}
