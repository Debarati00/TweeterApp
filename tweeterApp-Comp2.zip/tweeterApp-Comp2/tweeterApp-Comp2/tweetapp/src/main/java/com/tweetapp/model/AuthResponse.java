package com.tweetapp.model;

import java.util.List;

import lombok.*;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.annotation.Id;

/**
 * 
 * AuthResponse Entity class
 *
 */
@Data
@Document
public class AuthResponse {
	@Id
	private String uid;
	private String name;
	private boolean isValid;
	

}
