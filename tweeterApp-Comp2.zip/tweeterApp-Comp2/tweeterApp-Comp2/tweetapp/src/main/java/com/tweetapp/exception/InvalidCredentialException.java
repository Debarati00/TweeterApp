package com.tweetapp.exception;

public class InvalidCredentialException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	String message;
	
	public InvalidCredentialException(String string) {
		// TODO Auto-generated constructor stub
		this.message=string;
	}

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return this.message;
	}

	
}
