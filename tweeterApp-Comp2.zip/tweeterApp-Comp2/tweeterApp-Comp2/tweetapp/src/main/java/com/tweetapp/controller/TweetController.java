package com.tweetapp.controller;


import com.tweetapp.dao.TweetDao;
import com.tweetapp.model.Tweet;
import com.tweetapp.model.User;
import com.tweetapp.service.TweetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/tweeter")
public class TweetController {

    @Autowired
    private TweetDao tweetDao;

    @Autowired
    private TweetService tweetService;

    /**
     * Method to get All Tweets
    **/
    @GetMapping("/all")
    public ResponseEntity<?> getAllTweets() {
        List<Tweet> tweetList = tweetService.viewAllTweets();
        return new ResponseEntity<> (tweetList, HttpStatus.OK);
    }

    /**
     * Method to get Tweets Based on tweetId
     **/
    @GetMapping("/tweet/{tweetid}")
    public ResponseEntity<?> getTweetsById(@PathVariable("tweetid") String tweetId) {
        if (StringUtils.hasLength(tweetId)) {
            Tweet tweet = tweetService.findTweetById(tweetId);
            return new ResponseEntity<> (tweet, HttpStatus.OK);
        } else
            return new ResponseEntity<>("No Valid TweetId Found", HttpStatus.BAD_REQUEST);
    }

    /**
     * Method to add Tweets
     **/
    @PostMapping("/<username>/add")
    public ResponseEntity<?> createTweets(@RequestBody Tweet tweets) {
        if (!ObjectUtils.isEmpty(tweets)) {
            Tweet tweet = tweetService.addTweets(tweets);
            return new ResponseEntity<> (tweet, HttpStatus.OK);
        } else
            return new ResponseEntity<>("No body found", HttpStatus.BAD_REQUEST);
        }

    @GetMapping("/users/all")
    public ResponseEntity<?> getAllUsers() {
        List<User> userList = tweetService.viewAllUsers();
        return new ResponseEntity<> (userList, HttpStatus.OK);
    }

    @GetMapping("/user/{emailid}")
    ///user/search/username
    public ResponseEntity<?> getUserById(@PathVariable("emailid") String emailId) {
        if (StringUtils.hasLength(emailId)) {
            User user = tweetService.findUserByEmailId(emailId);
            return new ResponseEntity<> (user, HttpStatus.OK);
        } else
            return new ResponseEntity<>("No User Found By This Id", HttpStatus.BAD_REQUEST);
    }

    /**
     * Method to register a new User
     * @param user
     **/
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        if (!ObjectUtils.isEmpty(user)) {
            User addedUser = tweetService.addUsers(user);
            return new ResponseEntity<> (addedUser, HttpStatus.OK);
        } else
            return new ResponseEntity<>("No body found", HttpStatus.BAD_REQUEST);
    }

    /**
     * Method for logging in
     * @param user
     **/
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
            tweetService.login(user.getEmailId(), user.getPassword());
            return new ResponseEntity<>("Logged In Succesfully", HttpStatus.OK);
    }

    /**
     * Method for Forgot Password
     * @param user
     **/
    @PostMapping("/forgotpassword")
//    /<username>/forgot
    public ResponseEntity<?> forgotPassword(@RequestBody User user) {
        tweetService.forgetPassword(user.getEmailId(), user.getPassword());
            return new ResponseEntity<>("Password Reset Succesfull", HttpStatus.OK);
    }
}



