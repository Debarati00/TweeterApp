package com.tweetapp.service;

import com.tweetapp.TweetappApplication;
import com.tweetapp.dao.TweetDao;
import com.tweetapp.dao.UserDao;
import com.tweetapp.model.Tweet;
import com.tweetapp.model.User;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import org.springframework.util.StringUtils;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

@Service
public class TweetServiceImpl implements  TweetService {

    static final Logger LOGGER = LoggerFactory.getLogger(TweetappApplication.class);

    @Autowired
    private TweetDao tweetDao;

    @Autowired
    private UserDao userDao;

    @Override
    public List<Tweet> viewAllTweets() {
        LOGGER.info("Viewing List Of Active Tweets");
        return tweetDao.findAll();
    }

    @Override
    public Tweet findTweetById(String tweetId) {
        LOGGER.info("Viewing Tweet By Id");
        Tweet tweet = tweetDao.findByTweetId(tweetId);
        if (!ObjectUtils.isEmpty(tweet)){
            LOGGER.info("Tweet found");
            return tweet;
        }
        else
            LOGGER.info("Tweet Not found");
        return null;
    }

    @Override
    public Tweet addTweets(Tweet tweet) {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
//        Tweet tweetDb = new Tweet();
//        tweetDb.setTweetId(tweet.getTweetId());
//        tweetDb.setTweetText(tweet.getTweetText());
//        tweetDb.setTweetDate(String.valueOf(timestamp));
        LOGGER.info("Adding Tweet To Db");
        return tweetDao.save(tweet);
    }


    @Override
    public List<User> viewAllUsers() {
        LOGGER.info("Viewing List Of Active Users");
        return userDao.findAll();
    }

    @Override
    public User findUserByEmailId(String emailId) {
        LOGGER.info("Viewing User By UserId");
        User user = userDao.findUserByEmailId(emailId);
        if (!ObjectUtils.isEmpty(user)){
            LOGGER.info("User found");
            return user;
        }else{
            LOGGER.info("User Not found");
            return null;
        }
    }

    @Override
    public User addUsers(User user) {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
//        User userDb = new User();
//        userDb.setName(user.getName());
//        userDb.setPassword(user.getPassword());
//        userDb.setPhoneNo(user.getPhoneNo());
//        userDb.setUserId(user.getUserId());
//        userDb.setPicture(user.getPicture());
        LOGGER.info("Adding User To Db");
        return userDao.save(user);
    }

    @Override
    public void login(String emailId, String password) {
        if (StringUtils.hasLength(emailId) && StringUtils.hasLength(password)) {
            User user = userDao.findUserByEmailId(emailId);
            if (user.getPassword().equals(password)) {
                LOGGER.info("Password matched.");
            } else {
                LOGGER.error("Password didnt match. Please try again.");
            }
        }
    }

    @Override
    public void forgetPassword(String emailId , String password) {
        User user = userDao.findUserByEmailId(emailId);
        if (!ObjectUtils.isEmpty(user)) {
            user.setPassword(password);
            userDao.save(user);
            LOGGER.info("Password Reset Successful");
        } else {
            LOGGER.error("No user found by this emailId");
        }
    }
}
